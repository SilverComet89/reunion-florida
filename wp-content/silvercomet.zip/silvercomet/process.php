<?php

namespace SilverComet;

require_once __DIR__ . '/lib/Import.php';

use SilverComet\lib\Import;
use DOMDocument;
use DomXPath;

$import = new Import();

$data = $import->getFeed('https://www.propertyportalmarketing.com/xml/abire-apits.xml');
$import->dumpToFile(__DIR__ . '/source.xml', $data);

$dom = new DOMDocument();
$dom->preserveWhiteSpace = false;
$dom->formatOutput = true;
$dom->loadXML($data);
$xpath = new DOMXpath($dom);
$properties = $dom->getElementsByTagName('property');

$redundantNodes = [];
foreach ($xpath->query('//property') as $node) {
    if (strpos(strtolower($node->getElementsByTagName('PropertyName')->item(0)->nodeValue), 'reunion') === false) {
        $redundantNodes[] = $node;
    }
}

foreach ($redundantNodes as $redundantNode) {
    $redundantNode->parentNode->removeChild($redundantNode);
}

$dom->save(__DIR__ . '/stream.xml');
