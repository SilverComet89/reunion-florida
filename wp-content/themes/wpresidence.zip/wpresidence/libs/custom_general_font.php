<?php
echo 'body, h1, h2, h3, h4, h5, h6, h1 a, h2 a, h3 a, h4 a, h5 a, h6 a{font-family:"' . $general_font .'" !important;}';
?>
