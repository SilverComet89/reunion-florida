<?php
$layout=wpresidence_get_option('wp_estate_property_page_acc_order') ;
print_r($layout);