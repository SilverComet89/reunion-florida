<?php wp_enqueue_script('owl_carousel'); ?>
<div class="lightbox_property_wrapper modal_lightbox_property_wrapper">
    <div class="lightbox_property_wrapper_level2 ">


        <div  id="owl-demo-modal" class="owl-carousel owl-theme owl-demo-modal_class"> 
        </div>






        <div class="lighbox-image-close">
                <i class="fas fa-times" aria-hidden="true"></i>
        </div>
    </div>

    <div class="lighbox_overlay">
    </div>
</div>
